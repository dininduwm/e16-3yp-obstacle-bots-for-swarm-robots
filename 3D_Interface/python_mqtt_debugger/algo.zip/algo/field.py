import math
from robot import robot

def getDistance(robot1, robot2):

    # get the distance between the robot1 and robot2
    x1 = robot1.init_pos[0]
    y1 = robot1.init_pos[1]

    x2 = robot2.init_pos[0]
    y2 = robot2.init_pos[1]

    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)
    

def getForce(robot1, robot2, k = 15):
    
    # return the resultant force and the angle
    # of the force from robot2 on robot1

    # The const. k needs to be difined by the user

    x1 = robot1.init_pos[0]
    y1 = robot1.init_pos[1]

    x2 = robot2.init_pos[0]
    y2 = robot2.init_pos[1]

    force = 1 / (k * ((getDistance(robot1, robot2)) ** 2))

    if(x1 == x2): return [force, 90.00]
    return [force, math.degrees(math.atan((y1 - y2) / (x1 - x2)))]   #########

def calculateResultant(Forces):
    ''' 
        function takes the Forces list one the point
        and calculate the resultant force and direction
    '''
    import resaltant
    # print("Forces: ", Forces)
    return resaltant.getResultant(Forces)


def getResultant(robots_data, idx):
    ''' 
        function takes the index of the robot and 
        return the resultant force on that robot
    '''
    Forces = []

    for i in range(len(robots_data)):
        if i != idx:
            Forces.append(getForce(robots_data[idx], robots_data[i]))

    # calculate the Force for destination
    destination_robot = robot(robots_data[idx].des_pos, robots_data[idx].des_angle, -1, -1)
    Forces.append(getForce(destination_robot, robots_data[idx]))
    # give a magnitude factor to to destination force
    Forces[-1][0] *= len(robots_data)

    return calculateResultant(Forces)

    


